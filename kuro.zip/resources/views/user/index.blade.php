@include('user.layouts.header')
@include('user.layouts.navbar')
@include('user.layouts.menu')
@include('user.layouts.messages')

@yield('content')

@include('user.layouts.footer')