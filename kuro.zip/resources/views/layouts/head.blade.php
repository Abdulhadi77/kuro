





  <!-- Favicons -->
  <link href="storage/{{$settings->icon}}" rel="icon">
  <link href="{{asset('storage/assets/img/apple-touch-icon.png')}}" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="{{asset('storage/assets/vendor/aos/aos.css')}}" rel="stylesheet">
  <link href="{{asset('storage/assets/vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">
  <link href="{{asset('storage/assets/vendor/bootstrap-icons/bootstrap-icons.css')}}" rel="stylesheet">
  <link href="{{asset('storage/assets/vendor/glightbox/css/glightbox.min.css')}}" rel="stylesheet">
  <link href="{{asset('storage/assets/vendor/remixicon/remixicon.cs')}}'" rel="stylesheet">
  <link href="{{asset('storage/assets/vendor/swiper/swiper-bundle.min.css')}}" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="{{asset('storage/assets/css/style.css')}}" rel="stylesheet">
  <link href="{{asset('storage/assets/test.css')}}" rel="stylesheet">

  <link href="https://fonts.googleapis.com/css?family=Roboto:100,400,700,900" rel="stylesheet">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="{{asset('storage/assets/css/flipdown/flipdown.css')}}">
  <link rel="stylesheet" type="text/css" href="{{asset('storage/assets/css/style.css')}}">
  <script type="text/javascript" src="{{asset('storage/assets/js/flipdown/flipdown.js')}}"></script>
  <script type="text/javascript" src="{{asset('storage/assets/js/main.js')}}"></script>









