<div style="position: absolute;padding: 10px;text-align: center;width: 100%;z-index: 9999;background-color: #fffbdb;
border-color: #fffacc;"
     class="js-cookie-consent cookie-consent">

    <span class="cookie-consent__message">
        {!! trans('cookieConsent::texts.message') !!}
    </span>

    <button style="background-color: green" class=" btn primary-btn js-cookie-consent-agree cookie-consent__agree">
        {{ trans('cookieConsent::texts.agree') }}
    </button>

</div>
